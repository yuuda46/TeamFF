package account;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.SignUp;
import dao.SignUpDAO;

@WebServlet(urlPatterns={"/account/AccountDelete"})
public class AccountDelete extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        try {
            String email = request.getParameter("email");

            // アカウント情報取得
            SignUpDAO dao = new SignUpDAO();
            SignUp account = dao.findByEmail(email);
            if (account != null) {
                request.setAttribute("account", account);
                request.getRequestDispatcher("signup_delete.jsp").forward(request, response);
            } else {
                response.getWriter().println("アカウントが見つかりませんでした。");
            }
        } catch (Exception e) {
            e.printStackTrace(response.getWriter());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        try {
            String email = request.getParameter("email");

            // アカウント削除
            SignUpDAO dao = new SignUpDAO();
            SignUp signup = new SignUp();
            signup.setEmail(email);
            int result = dao.delete(signup);

            if (result > 0) {
                request.getRequestDispatcher("signup_delete_done.jsp").forward(request, response);
            } else {
                response.getWriter().println("削除に失敗しました。");
            }
        } catch (Exception e) {
            e.printStackTrace(response.getWriter());
        }
    }
}
