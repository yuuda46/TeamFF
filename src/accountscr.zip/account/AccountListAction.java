package account;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.SignUp;
import dao.SignUpDAO;
import tool.Action;

public class AccountListAction extends Action {
    public String execute(
            HttpServletRequest request, HttpServletResponse response
    ) throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            // サインアップDAOを使用してDBからアカウント情報を取得
            SignUpDAO dao = new SignUpDAO();
            List<SignUp> accountList = dao.all();
            // DAOのallメソッドで全てのアカウントを取得
            System.out.println(accountList);
            //System.out.println("ooo");

            // アトリビュートにアカウントリストをセット
            request.setAttribute("accountList", accountList);

        } catch (Exception e) {
            e.printStackTrace(out);
        }
        return "signup_list.jsp"; // JSPページへフォワード
    }
}
